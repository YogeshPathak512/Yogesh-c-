﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace stringAssignment
{
	public class ReverseString
	{

        


			static void Main()
			{
				string sentence = "Hello World";
				ReverseWords(sentence);
			   Console.ReadLine();

		    }

		static void ReverseWords(string sentence)
			{
				string[] words = sentence.Split(' ');
				Array.Reverse(words);
				Console.WriteLine(string.Join(" ", words));

			}
			


		


    }
}
