﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace stringAssignment
{
	internal class Substrings
	{

		static void Main(string[] args)

		{

			string str;

			Console.WriteLine("Enter a string: ");

			str = Console.ReadLine();



			for (int i = 0; i < str.Length; i++)

			{

				StringBuilder newString = new StringBuilder();

				for (int j = i; j < str.Length; j++)

				{

					newString.Append(str[j]);

					Console.Write(newString + " ");

				}

			}

			Console.ReadLine();

		}




	}
}
