﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Channels;
using System.Threading.Tasks;

namespace stringAssignment
{
	 public class Anagram
	{
		public static bool AreAnagrams(string s1, string s2)
		{
			// Convert strings to character arrays
			char[] charArray1 = s1.ToCharArray();
			char[] charArray2 = s2.ToCharArray();

			// Sort both character arrays
			Array.Sort(charArray1);
			Array.Sort(charArray2);

			// Compare sorted character arrays
			return new string(charArray1)
				== new string(charArray2);
		}

		public static void Main(string[] args)
		{
			string str1 = "listen";
			string str2 = "silent";

			if (AreAnagrams(str1, str2))
			{
				Console.WriteLine("Anagram ");
			}
			else
			{
				Console.WriteLine("not a anagram");
			}

			Console.ReadLine();	








		}

	}
}
