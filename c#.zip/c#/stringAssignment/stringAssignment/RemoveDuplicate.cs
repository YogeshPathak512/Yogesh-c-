﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace stringAssignment
{
	internal class RemoveDuplicate
	{



		static void Main(string[] args)

		{
			Console.WriteLine("Enter a string");

			String str = Console.ReadLine();

			string result = String.Empty; //Represents the empty string



			for (int i = 0; i < str.Length; i++)

			{

				if (!result.Contains(str[i]))

					result += str[i];

			}

			Console.WriteLine(result);

			Console.ReadLine();

		}

	}






}

