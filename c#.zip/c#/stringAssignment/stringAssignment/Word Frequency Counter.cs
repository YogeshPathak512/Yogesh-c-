﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

public class WordFrequency
{
	public static Dictionary<string, int> GetWordFrequency(string paragraph)
	{
		// Convert text to lowercase and remove punctuation using regex
		string cleanedParagraph = Regex.Replace(paragraph.ToLower(), @"[^\w\s]", "");

		// Split the cleaned paragraph into words using spaces
		string[] words = cleanedParagraph.Split(new[] { ' ', '\n', '\r', '\t' }, StringSplitOptions.RemoveEmptyEntries);

		// Use a dictionary to count word occurrences
		Dictionary<string, int> wordCount = new Dictionary<string, int>();

		foreach (string word in words)
		{
			if (wordCount.ContainsKey(word))
			{
				wordCount[word]++;
			}
			else
			{
				wordCount[word] = 1;
			}
		}

		return wordCount;
	}

	public static void Main(string[] args)
	{
		string paragraph = "This is a sample paragraph. This paragraph is a sample text!";

		Dictionary<string, int> frequencies = GetWordFrequency(paragraph);

		// Display word frequencies
		foreach (var item in frequencies)
		{
			Console.WriteLine($"Word: {item.Key}, Frequency: {item.Value}");
		}
	}
}

