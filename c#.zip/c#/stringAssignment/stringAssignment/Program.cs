﻿internal class Program
{
	public static void Main(string[] args)
	{

		Console.WriteLine("Enter a string :");
		string str = Console.ReadLine();
		str=str.ToLower();	
		string revstring  = "";

		for (int i =str.Length - 1; i >= 0; i--)
		{
			revstring = revstring + str[i];

		}

		if(str ==revstring)
		{

            Console.WriteLine("given string is palindrome");


		}
		else
		{

			Console.WriteLine(" not a palindrome");
		}

		Console.ReadLine();
	}
}