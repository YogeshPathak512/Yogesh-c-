﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C_Asiignment1
{
	internal class demo
	{
        static void Main(string[] args)
        {
            
        byte b = 0;
            int i = 1;
            short s = 0;
            long l = 22233;
            string str = "";
            double a = 0;
            float f = 1.2f;

            long a1 = 23;
            int l2 = (int)a1;

            Console.WriteLine(l2);




        }

    }
}
