﻿// See https://aka.ms/new-console-template for more information
using System;
using System.Diagnostics.CodeAnalysis;

class Program

{
    //   1. C# Program to Print “Hello, World!”
    public static void Main()
    {

        // Console.WriteLine("Hello, World!");




        //  2. C# Program to Add Two Integers.
         int a = 22;
         int b = 45;
         int sum;

         sum = a + b;
         Console.WriteLine(sum);

        // //3.C# Program to Swap Values of Two Variables.

        // int x = 22;
        // int y = 44;

        // Console.WriteLine("Before swap"+x+", "+y);


        // x = x + y;
        // y=x-y; 
        // x = x - y;
        // Console.WriteLine("after  swap"+ x + ", " + y);



        // //.C# Program to Multiply two Floating Point Numbers


        // float F1 = 2.0f;
        // float F2 = 1.0f;
        // float multiply;

        // multiply = F1 * F2;


        // Console.WriteLine(multiply);



        ////#5 Programto perform all arithmetic operations

        int num1 = 12;
        int num2 = 13;
        //SUM
        Console.WriteLine(num2 + num1);
        //DIFFRENCE
        Console.WriteLine(num2 - num1);
        //Multiple
        Console.WriteLine(num2 * num1);
        //Module
        Console.WriteLine(num2 % num1);



        // //.C# Program to convert feet to meter

        double feet, meter;
        Console.WriteLine("Input Feet :");
        feet = Convert.ToDouble(Console.ReadLine());
        meter = feet / 3.2808399;
        Console.WriteLine("\n feet in meter =" + meter);

        ////# Program to convert celcius to farenheit

        float celsius = 36;
        Console.WriteLine("Temperature in celsius is: " + celsius);
        float fahrenheit = ((celsius * 9) / 5) + 32;
        Console.WriteLine("Temperature in Fahrenheit is: " + fahrenheit);
        Console.ReadKey();


        //# Program to convert farenheit to celcius

        double celsius1;
        double fahrenheit1 = 97;
        Console.WriteLine("Fahrenheit: " + fahrenheit1);
        celsius1 = (fahrenheit1 - 32) * 5 / 9;
        Console.WriteLine("celsius1: " + celsius1);



        //C# Program to find the Size of data types

        Console.WriteLine("sizeof(int): {0}", sizeof(int));
        Console.WriteLine("sizeof(float): {0}", sizeof(float));
        Console.WriteLine("sizeof(char): {0}", sizeof(char));
        Console.WriteLine("sizeof(double): {0}", sizeof(double));
        Console.WriteLine("sizeof(bool): {0}", sizeof(bool));

        //# Program to Print ASCII Value

        char c = 'e';
        int ascii = c;
        Console.WriteLine("The ASCII value of " + c + " is: " + ascii);


        //C# Program to Calculate Area of Circle
        Console.Write("Enter Radius: ");
        double rad = Convert.ToDouble(Console.ReadLine());
        double area = Math.PI * rad * rad;
        Console.WriteLine("Area of circle is: " + area);

       //# Program to Calculate Area of Square

        Console.WriteLine("Enter the Side of Square: ");
        int Side = Convert.ToInt32(Console.ReadLine());
        int Area = Side * Side;
        Console.WriteLine($"Area of Square with side {Side} is {Area}");




		//# Program to Calculate Area of Rectangle


       Console.WriteLine("Enter the Length of a Rectangle: ");
        int Length = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("Enter the Breadth of a Rectangle: ");
        int Breadth = Convert.ToInt32(Console.ReadLine());
        int Area1= Length * Breadth;
        Console.WriteLine($"Area of Length {Length} and Breadth {Breadth} Rectangle is {Area1}");



        //C# Program to convert days to years, weeks and days
        int ndays, year, week, days, DAYSINWEEK = 7;
        Console.WriteLine("Enter the number of days");
        ndays = int.Parse(Console.ReadLine());
        year = ndays / 365;
        week = (ndays % 365) / DAYSINWEEK;
        days = (ndays % 365) % DAYSINWEEK;
        Console.WriteLine("{0} is equivalent to {1}years, {2}weeks and {3}days",
                           ndays, year, week, days);

    }










}

