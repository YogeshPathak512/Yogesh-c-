﻿using System;
using System.Buffers;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C_Asiignment1.Day3_Assignment
{
	class Day3Assignment1
	{

          // ### Largest no

		//static void largest(int x, int y, int z)
		//{
		//	int max = x;

		//	if (x >= y && x >= z)
		//		max = x;
		//	else if (y >= x && y >= z)
		//		max = y;
		//	else
		//		max = z;

		//	Console.WriteLine("largest number among {0}, {1} and {2} is: {3}",
		//					   x, y, z, max);




		//}
		//static void Main(string[] args)
		//{
		//	largest(100, 50, 25);
		//	largest(50, 50, 25);

		//}


		//C# Program to Find the Largest Number using Conditional Operator.

		//static void largest(int x, int y, int z)
		//{
		//	int max = x;
		//	max = (x > y) ? ((x > z) ? x : z) : ((y > z) ? y : z);
		//	Console.WriteLine("largest number among {0}, {1} and {2} is: {3}",
		//					   x, y, z, max);
		//}

		//static void Main(string[] args)
		//{
		//	largest(100, 50, 25);
		//	largest(50, 50, 25);
		//}



		//C# program to check leap year using conditional Operator.

		//static bool CheckYear(int year)
		//{
		//	// Leap year condition: 
		//	// 1. If the year is divisible by 4 and not divisible by 100, or
		//	// 2. If the year is divisible by 400.
		//	if ((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0))
		//	{
		//		return true; // It's a leap year
		//	}
		//	else
		//	{
		//		return false; // It's not a leap year
		//	}
		//}

		//static void Main()
		//{
		//	int year = 2001; // Sample input to test

		//	// Call the CheckYear function to determine if it's a leap year
		//	if (CheckYear(year))
		//	{
		//		Console.WriteLine("Leap Year");
		//	}
		//	else
		//	{
		//		Console.WriteLine("Not a Leap Year");
		//	}
		//}


		//C# program to check number is positive, negative or zero.


		static int n = 19;
		public static void Main()
		{
			//// checking for positive, negative or 0
			//if (n > 0)
			//{
			//	Console.WriteLine("Positive Number!");
			//}
			//else if (n == 0)
			//{
			//	Console.WriteLine("Zero");
			//}
			//else
			//{
			//	Console.WriteLine("Negative Number!");
			//}

		


			//C# program to print day name of week.


			//Console.WriteLine("Enter a date (format: yyyy-mm-dd):");
			

			//try
			//{
			//	Reading the date input from the user

			//   DateTime inputDate = DateTime.Parse(Console.ReadLine());

			//	Getting the day of the week for the given date

			//   string dayOfWeek = inputDate.DayOfWeek.ToString();

			//	Printing the day name
			//		Console.WriteLine("The day of the week is: " + dayOfWeek);
			//}
			//catch (FormatException)
			//{
			//	Console.WriteLine("Invalid date format! Please enter the date in the format: yyyy-mm-dd.");
			//}






			//}

			//C# program to accept two integers and check whether they are equal or not.

			//int Number1 = 0, Number2 =0;
			//         Console.WriteLine("Enter the Number1");
			//Number1 = Convert.ToInt32(Console.ReadLine());
			//Console.WriteLine("Enter the Number2");
			//Number2 = Convert.ToInt32(Console.ReadLine());
			//if (Number1 == Number2)
			//{
			//             Console.WriteLine("no are equal", Number1, Number2);
			//}
			//else
			//{
			//	Console.WriteLine("numbers are not equal");
			//}


			////C# program to detrermine a candidate’s age is eligible for casting the vote or not.
			//try
			//{
			//	Console.WriteLine("Enter a Age");
			//	int age = Convert.ToInt32(Console.ReadLine());

			//	if (age >= 18)
			//	{
			//		Console.WriteLine("Eligible for vote");
			//	}
			//	else
			//	{
			//		Console.WriteLine("NOT ELIGIBLE");
			//	}
			//}
			//catch (Exception ex) 
			//{
			//	Console.WriteLine(ex.Message);

			//}
			//	Console.ReadLine();







			//C# program to calculate the total marks, percentage and division of student.


			//int r, marks1, marks2, marks3, total;

			//// Declare percentage variable 
			//float percentage;
			//string n1;

			//// Enter student roll number 
			//Console.WriteLine("Enter Student Roll Number :");
			//r = Convert.ToInt32(Console.ReadLine());

			//// Enter student name 
			//Console.WriteLine("Enter Student Name :");
			//n1= Console.ReadLine();

			//// Enter student subject 1 marks 
			//Console.WriteLine("Enter Subject-1 Marks : ");
			//marks1 = Convert.ToInt32(Console.ReadLine());

			//// Enter student subject 2 marks 
			//Console.WriteLine("Enter Subject-2 Marks : ");
			//marks2 = Convert.ToInt32(Console.ReadLine());

			//// Enter student subject 3 marks 
			//Console.WriteLine("Enter Subject-3 Marks :");
			//marks3 = Convert.ToInt32(Console.ReadLine());

			//// Calculate total marks 
			//total = marks1 + marks2 + marks3;

			//// Calculate percentage 
			//percentage = total / 3.0f;

			//// Display the final result 
			//Console.WriteLine("Final result of {0} is:", n);
			//Console.WriteLine("Total Marks : " + total);
			//Console.WriteLine("Percentage : " + percentage);

			//// Calculate grades 
			//if (percentage <= 35)
			//{
			//	Console.WriteLine("Grade is F");
			//}
			//else if (percentage >= 34 && percentage <= 39)
			//{
			//	Console.WriteLine("Grade is D");
			//}
			//else if (percentage >= 40 && percentage <= 59)
			//{
			//	Console.WriteLine("Grade is C");
			//}
			//else if (percentage >= 60 && percentage <= 69)
			//{
			//	Console.WriteLine("Grade is B");
			//}
			//else if (percentage >= 70 && percentage <= 79)
			//{
			//	Console.WriteLine("Grade is B+");
			//}
			//else if (percentage >= 80 && percentage <= 90)
			//{
			//	Console.WriteLine("Grade is A");
			//}
			//else if (percentage >= 91)
			//{
			//	Console.WriteLine("Grade is A+");
			//}





			// C# program to enter month number and print number of days in month. 


			//Console.WriteLine("Enter month number(1-12): ");
			//	int month=Convert.ToInt32(Console.ReadLine());
			//		switch (month)
			//		{
			//			case 1:
			//                  Console.WriteLine("31 days"); 
			//				break;
			//			case 2:
			//                  Console.WriteLine("28/29 days"); 
			//				break;
			//			case 3:
			//                 Console.WriteLine("31 days");
			//			break;
			//			case 4:
			//			Console.WriteLine("30 days");
			//			break;
			//			case 5:
			//			Console.WriteLine("31 days");
			//			break;
			//			case 6:
			//			Console.WriteLine("30 days");
			//			break;
			//			case 7:
			//			Console.WriteLine("31 days");
			//			break;
			//			case 8:
			//			Console.WriteLine("31 days");
			//			break;
			//			case 9:
			//			Console.WriteLine("30 days");
			//			break;
			//			case 10:
			//			Console.WriteLine("31 days");
			//			break;
			//			case 11:
			//			Console.WriteLine("30 days");
			//			break;
			//			case 12:
			//			Console.WriteLine("31 days");
			//			break;
			//			default:
			//                  Console.WriteLine("Invalid input! Please enter month number between 1-12");
			//			break;

			//	    }


			//C# program to check whether a triangle can be formed by the given value for the angles.
			int anga, angb, angc, sum;  
				
				Console.Write("Input angle 1 of triangle: ");
				anga = Convert.ToInt32(Console.ReadLine());

				Console.Write("Input angle 2 of triangle: ");
				angb = Convert.ToInt32(Console.ReadLine());

				Console.Write("Input angle 3 of triangle: ");
				angc = Convert.ToInt32(Console.ReadLine());

				
				sum = anga + angb + angc;  

				if (sum == 180)
				{
					Console.Write("The triangle is formed.\n");  
				}
				else
				{
					Console.Write("The triangle is not valid.\n");  
				}
			}
		}






















	}




































