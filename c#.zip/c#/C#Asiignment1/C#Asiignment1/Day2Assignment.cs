﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C_Asiignment1
{
	public class Day2Assignment
	{
		static void Main()
		{

			//byte a = 10;
			//byte b = 20;
			//byte sum = (a + b);

			//Console.WriteLine(sum);

			//1) Write a C# Sharp program that takes userid and password as input (type string). After 3 wrong attempts, user will be rejected. 

			int loginAttempts = 0;


			for (int i = 0; i < 3; i++)
			{
				Console.WriteLine("Enter username");
				string username = Console.ReadLine();
				Console.WriteLine("Enter password");
				string password = Console.ReadLine();

				if (username != "yogesh12" || password != "Yogesh@12")
					loginAttempts++;
				else
					break;
			}


			if (loginAttempts > 2)
				Console.WriteLine("Login failure please Try Again with vaild password ");
			else
				Console.WriteLine("Login successful");

			Console.ReadKey();


			//2)Write a C# Sharp program that takes a character as input and check the input (lowercase) is a vowel, a digit, or any other symbol.

			char symbol;

			// Input a symbol from the user
			Console.Write("Input a character: ");
			symbol = Convert.ToChar(Console.ReadLine());

			// Check if the entered symbol is a lowercase vowel
			if ((symbol == 'a') || (symbol == 'e') || (symbol == 'i') ||
				(symbol == 'o') || (symbol == 'u'))
			{
				Console.WriteLine("It's a lowercase vowel.");
			}
			// Check if the entered symbol is a digit
			else if ((symbol >= '0') && (symbol <= '9'))
			{
				Console.WriteLine("It's a digit.");
			}
			// If the entered symbol doesn't match the above conditions, it's another symbol
			else
			{
				Console.Write("It's another symbol.");
			}
			



		}





	}
}
