﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C_Asiignment1.Day3_Assignment
{
	public class EvenorOdd
	{
		//C# Program to check whether an integer entered by the user is odd or even


		static void Main(string[] args)
		{

			Console.WriteLine("Enter a number");
			int num = Convert.ToInt32(Console.ReadLine());

			if (num % 2 == 0)
			{
				Console.WriteLine("numer is even");

			}

			else
			{
				Console.WriteLine(" number is odd");
			}

		}


		static void largest(int x, int y, int z)
		{
			int max = x;

			if (x >= y && x >= z)
				max = x;
			else if (y >= x && y >= z)
				max = y;
			else
				max = z;

			Console.WriteLine("largest number among {0}, {1} and {2} is: {3}",
							   x, y, z, max);



			static void Main(string[] args)
			{
				largest(100, 50, 25);
				largest(50, 50, 25);

			}
		}
	}
}
