﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssignmentDay1
{
    internal class Program
    {   


        static void Main(string[] args)
        {

            int numberOfUpperLetter = 0 , numberOfNumber =0 , numberOfSpecialCharacter =0;

            Console.WriteLine("Enter the input");
            string userInput = Console.ReadLine();

           

            Console.WriteLine( userInput.Trim());
            foreach (char item in userInput)
            {
                if (char.IsLetter(item))
                {
                    if (char.IsUpper(item))
                    {
                        numberOfUpperLetter++;
                    }

                }else if (char.IsNumber(item))
                {
                    numberOfNumber++;

                }else if (char.IsWhiteSpace(item))
                {

                }
                else
                {
                    numberOfSpecialCharacter++;
                }
            }

            Console.WriteLine("numberOfUpperLetter :"+ numberOfUpperLetter);
            Console.WriteLine("numberOfNumber :"+ numberOfNumber);
            Console.WriteLine("numberOfSpecialCharacter :"+ numberOfSpecialCharacter);
            Console.Read();
        }
    }
}
