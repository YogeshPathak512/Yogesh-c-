﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string s = Console.ReadLine();
            int n = Convert.ToInt32(s);

            for (int i = 1; i <= n; i++)
            {

                if (i >= n)
                {
                    for (int k = 1; k <= n ; k++)
                    {
                        for (int l = 1; l <= (n * 2) - (2 * k - 1); l++)
                        {
                            Console.Write(l);
                        }
                        Console.WriteLine();
                    }
                }
                else
                {

                    for (int j = 1; j <= ((2 * i) - 1); j++)
                    {
                        Console.Write(j);
                    }
                    Console.WriteLine();
                }
            }
        }
    }
    }

